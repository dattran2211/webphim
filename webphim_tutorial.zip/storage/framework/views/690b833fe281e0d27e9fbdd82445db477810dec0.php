
<?php $__env->startSection('content'); ?>

<table class="table">
    <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Title</th>
        <th scope="col">Slug</th>                    <th scope="col">Description</th>

        <th scope="col">Description</th>
        <th scope="col">Active/Inactive</th>

        <th scope="col">Manager</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($cate->id); ?></th>
        <td><?php echo e($cate->title); ?></td>
        <td><?php echo e($cate->slug); ?></td>

        <td><?php echo e($cate->description); ?></td>
        <td>
            <?php if($cate->status): ?>
              Hiển thị
            <?php else: ?>
              Không
            <?php endif; ?>
        </td>
        <td>
            <?php echo Form::open(['method'=>'DELETE','route'=>['country.destroy',$cate->id],'onsubmit'=>'return confirm("Xóa?")']); ?>

            <?php echo Form::submit('Xóa', ['class'=>'btn btn-danger']); ?>


            <?php echo Form::close(); ?>

            <a href="<?php echo e(route('country.edit',$cate->id)); ?>" class="btn btn-warning">Sửa</a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webphim_tutorial\resources\views/admincp/country/index.blade.php ENDPATH**/ ?>