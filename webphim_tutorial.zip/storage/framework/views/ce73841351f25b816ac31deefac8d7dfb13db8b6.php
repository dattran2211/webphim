
<?php $__env->startSection('content'); ?>
<table class="table" id="tablephim">
    <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Tên link</th>                    
        <th scope="col">Mô tả</th>
        <th scope="col">Status</th>
      </tr>
    </thead>
    <tbody class="order_position">
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$linkmovie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr id="<?php echo e($linkmovie->id); ?>">
        <th scope="row"><?php echo e($linkmovie->id); ?></th>
        <td><?php echo e($linkmovie->title); ?></td>
        <td><?php echo e($linkmovie->description); ?></td>
        <td>
            <?php if($linkmovie->status): ?>
              Hiển thị
            <?php else: ?>
              Không
            <?php endif; ?>
        </td>
        <td>
            <?php echo Form::open(['method'=>'DELETE','route'=>['linkmovie.destroy',$linkmovie->id],'onsubmit'=>'return confirm("Xóa?")']); ?>

            <?php echo Form::submit('Xóa', ['class'=>'btn btn-danger']); ?>


            <?php echo Form::close(); ?>

            <a href="<?php echo e(route('linkmovie.edit',$linkmovie->id)); ?>" class="btn btn-warning">Sửa</a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
  </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webphim_tutorial\resources\views/admincp/linkmovie/index.blade.php ENDPATH**/ ?>