

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Quản lý thể loại</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(!isset($genre)): ?>
                    <?php echo Form::open(['route' => 'genre.store', 'method' => 'POST']); ?>

                    <?php else: ?>
                    <?php echo Form::open(['route' => ['genre.update',$genre->id],'method' => 'PUT']); ?>

                    <?php endif; ?>

                    <?php echo Form::open(['route' => 'genre.store', 'method' => 'POST']); ?>

                    <div class="form-group">
                    <?php echo Form::label('title', 'Title', []); ?>

                    <?php echo Form::text('title', isset($genre) ? $genre->title : '', ['class'=>'form-control','placeholder'=>'Nhập vào dữ liệu','id'=>'slug','onkeyup'=>'ChangeToSlug()']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('slug', 'Slug', []); ?>

                        <?php echo Form::text('slug', isset($genre) ? $genre->slug : '', ['class'=>'form-control','placeholder'=>'Nhập vào dữ liệu','id'=>'convert_slug']); ?>

                        </div>

                    <div class="form-group">
                        <?php echo Form::label('description', 'Description', []); ?>

                        <?php echo Form::textarea('description', isset($genre) ? $genre->description : '', ['style'=>'resize:none','class'=>'form-control','placeholder'=>'Nhập vào dữ liệu','id'=>'title']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('active', 'Active', []); ?>

                        <?php echo Form::select('status', ['1'=>'Hiển thị','0'=>'Không'], isset($genre) ? $genre->status : '', ['class'=>'form-control']); ?>                    
                    </div>
                    <?php if(!isset($genre)): ?>
                    <?php echo Form::submit('Thêm dữ liệu', ['class'=>'btn btn-success']); ?>

                    <?php else: ?>
                    <?php echo Form::submit('Cập nhật', ['class'=>'btn btn-success']); ?>

                     <?php endif; ?>
                    <?php echo Form::close(); ?>

                </div>
            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webphim_tutorial\resources\views/admincp/genre/form.blade.php ENDPATH**/ ?>