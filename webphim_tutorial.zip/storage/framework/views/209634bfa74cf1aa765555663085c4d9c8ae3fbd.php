

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Quản lý thông tin website</div>

                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <li><?php echo e($error); ?></li>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                  
                    <?php echo Form::open(['route' => ['info.update',$info->id],'method' => 'PUT','enctype'=>'multipart/form-data']); ?>


                    <div class="form-group">
                    <?php echo Form::label('title', 'Tiêu đề web', []); ?>

                    <?php echo Form::text('title', isset($info) ? $info->title : '', ['class'=>'form-control','placeholder'=>'Nhập vào dữ liệu','id'=>'slug','onkeyup'=>'ChangeToSlug()']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('description', 'Mô tả website', []); ?>

                        <?php echo Form::textarea('description', isset($info) ? $info->description : '', ['style'=>'resize:none','class'=>'form-control','placeholder'=>'Nhập vào dữ liệu','id'=>'title']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('copyright', 'Copy Right', []); ?>

                        <?php echo Form::textarea('copyright', isset($info) ? $info->copyright : '', ['style'=>'resize:none','class'=>'form-control','placeholder'=>'Nhập vào dữ liệu','id'=>'title']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('image', 'Hình ảnh logo', []); ?>

                        <?php echo Form::file('image', ['class'=>'form-control-file']); ?>

                    </br>                    
                    <?php if(isset($info)): ?>
                    <img width="20%" src="<?php echo e(asset('uploads/logo/'.$info->logo)); ?>">
                    <?php endif; ?>
                    </div>
                      <?php echo Form::submit('Cập nhật website', ['class'=>'btn btn-success']); ?>

                    <?php echo Form::close(); ?>

                </div>
            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webphim_tutorial\resources\views/admincp/info/form.blade.php ENDPATH**/ ?>