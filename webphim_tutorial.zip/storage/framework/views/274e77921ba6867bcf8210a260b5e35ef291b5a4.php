<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="banner_quangcao" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <a href="" target="_blank">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" style="text-align: center;font-size: 36px;color:black">Hướng dẫn</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <img src="<?php echo e(asset('imgs/movie-banner/1.jpg')); ?>">
      </div>
      
    </div>
    </a>
  </div>
</div><?php /**PATH C:\xampp\htdocs\webphim_tutorial\resources\views/pages/include/banner.blade.php ENDPATH**/ ?>