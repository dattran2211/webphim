

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <a href="<?php echo e(route('movie.index')); ?>" class="btn btn-primary">Liệt kê phim</a>

                <div class="card-header">Quản lý phim</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(!isset($movie)): ?>
                    <?php echo Form::open(['route' => 'movie.store', 'method' => 'POST','enctype'=>'multipart/form-data']); ?>

                    <?php else: ?>
                    <?php echo Form::open(['route' => ['movie.update',$movie->id],'method' => 'PUT','enctype'=>'multipart/form-data']); ?>

                    <?php endif; ?>

                    <?php echo Form::open(['route' => 'movie.store', 'method' => 'POST']); ?>

                    <div class="form-group">
                    <?php echo Form::label('title', 'Title', []); ?>

                    <?php echo Form::text('title', isset($movie) ? $movie->title : '', ['class'=>'form-control','placeholder'=>'Nhập vào dữ liệu','id'=>'slug','onkeyup'=>'ChangeToSlug()']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('trailer', 'Trailer', []); ?>

                        <?php echo Form::text('trailer', isset($movie) ? $movie->trailer : '', ['class'=>'form-control','placeholder'=>'Nhập vào dữ liệu']); ?>

                        </div>

                    <div class="form-group">
                            <?php echo Form::label('sotap', 'Số tập', []); ?>

                            <?php echo Form::text('sotap', isset($movie) ? $movie->sotap : '', ['class'=>'form-control','placeholder'=>'Nhập vào dữ liệu']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('thoiluong', 'Thời lượng', []); ?>

                        <?php echo Form::text('thoiluong', isset($movie) ? $movie->thoiluong : '', ['class'=>'form-control','placeholder'=>'Nhập vào dữ liệu']); ?>

                        </div>

                    <div class="form-group">
                        <?php echo Form::label('name_english', 'Title English', []); ?>

                        <?php echo Form::text('name_english', isset($movie) ? $movie->name_english : '', ['class'=>'form-control','placeholder'=>'Nhập vào dữ liệu']); ?>

                        </div>

                    <div class="form-group">
                        <?php echo Form::label('slug', 'Slug', []); ?>

                        <?php echo Form::text('slug', isset($movie) ? $movie->slug : '', ['class'=>'form-control','placeholder'=>'Nhập vào dữ liệu','id'=>'convert_slug']); ?>

                        </div>

                    <div class="form-group">
                        <?php echo Form::label('tags', 'Tags phim', []); ?>

                        <?php echo Form::textarea('tags', isset($movie) ? $movie->tags : '', ['style'=>'resize:none','class'=>'form-control','placeholder'=>'Nhập vào dữ liệu']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('description', 'Description', []); ?>

                        <?php echo Form::textarea('description', isset($movie) ? $movie->description : '', ['style'=>'resize:none','class'=>'form-control','placeholder'=>'Nhập vào dữ liệu','id'=>'description']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('active', 'Active', []); ?>

                        <?php echo Form::select('status', ['1'=>'Hiển thị','0'=>'Không'], isset($movie) ? $movie->status : '', ['class'=>'form-control']); ?>                    
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('resolution', 'Định dạng', []); ?>

                        <?php echo Form::select('resolution', ['1'=>'SD','0'=>'HD','2'=>'HDCam','3'=>'Cam','4'=>'FullHD','5'=>'Trailer'], isset($movie) ? $movie->resolution : '', ['class'=>'form-control']); ?>                    
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('category', 'Danh mục', []); ?>

                        <?php echo Form::select('category_id', $category ,isset($movie) ? $movie->category_id : '', ['class'=>'form-control']); ?>                    
                    </div>

                    <div class="form-group">
                        <?php echo Form::label('thuocphim', 'Thuộc thể loại phim', []); ?>

                        <?php echo Form::select('thuocphim', ['phimle'=>'Phim lẻ','phimbo'=>'Phim bộ'],isset($movie) ? $movie->thuocphim : '', ['class'=>'form-control']); ?>                    
                    </div>

                    <div class="form-group">
                        <?php echo Form::label('country', 'Quốc Gia', []); ?>

                        <?php echo Form::select('country_id', $country, isset($movie) ? $movie->country_id : '', ['class'=>'form-control']); ?>                    
                    </div>

                    <div class="form-group">
                        <?php echo Form::label('genre', 'Thể loại', []); ?><br>
                        
                        <?php $__currentLoopData = $list_genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $gen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(isset($movie)): ?>
                        <?php echo Form::checkbox('genre[]',$gen->id, isset($movie_genre) && $movie_genre->contains($gen->id) ? true : false); ?>

                        <?php else: ?>
                        <?php echo Form::checkbox('genre[]',$gen->id,''); ?>

                        <?php endif; ?>
                        <?php echo Form::label('genre', $gen->title); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="form-group">
                        <?php echo Form::label('Hot', 'Phim Hot', []); ?>

                        <?php echo Form::select('phim_hot', ['1'=>'Có','0'=>'Không'],isset($movie) ? $movie->phim_hot : '', ['class'=>'form-control']); ?>                    
                    </div>

                    <div class="form-group">
                        <?php echo Form::label('phude', 'Phụ đề', []); ?>

                        <?php echo Form::select('phude', ['1'=>'Thuyết minh','0'=>'Phụ đề'],isset($movie) ? $movie->phude : '', ['class'=>'form-control']); ?>                    
                    </div>

                    <div class="form-group">
                        <?php echo Form::label('image', 'Image', []); ?>

                        <?php echo Form::file('image', ['class'=>'form-control-file']); ?>

                    </br>                    
                    <?php if(isset($movie)): ?>
                    <img width="20%" src="<?php echo e(asset('uploads/movie/'.$movie->image)); ?>">
                    <?php endif; ?>
                    </div>

                    <?php if(!isset($movie)): ?>
                    <?php echo Form::submit('Thêm dữ liệu', ['class'=>'btn btn-success']); ?>

                    <?php else: ?>
                    <?php echo Form::submit('Cập nhật', ['class'=>'btn btn-success']); ?>

                     <?php endif; ?>
                    <?php echo Form::close(); ?>

                </div>
            </div>
           
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webphim_tutorial\resources\views/admincp/movie/form.blade.php ENDPATH**/ ?>