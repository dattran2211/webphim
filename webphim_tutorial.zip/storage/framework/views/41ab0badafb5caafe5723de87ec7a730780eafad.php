

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">

                <div class="table-responsive">
                    <table class="table" id="tablephim">

                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Tên phim</th>
                            <th scope="col">Hình ảnh phim</th>
                            <th scope="col">Tập phim</th>
                            <th scope="col">Link phim</th>
                            <th scope="col">Link Server</th>

                            
                            <th scope="col">Quản lý</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $list_episode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $episode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($key); ?></th>
                                <td><?php echo e($episode->movie->title); ?></td>
                                <td><img width="100%" height="100px"
                                        src="<?php echo e(asset('uploads/movie/' . $episode->movie->image)); ?>"></td>
                                <td><?php echo e($episode->episode); ?></td>
                                <td><?php echo $episode->linkphim; ?></td>
                                <td>
                                    <?php echo e(['Hydrax', 'Ok.ru', 'doodstream', 'vimeo', 'thường'][$episode->linkserver] ?? 'Trailer'); ?>

                                  </td>
                                  

                                
                                <td>
                                    <?php echo Form::open([
                                        'method' => 'DELETE',
                                        'route' => ['episode.destroy', $episode->id],
                                        'onsubmit' => 'return confirm("Xóa?")',
                                    ]); ?>

                                    <?php echo Form::submit('Xóa', ['class' => 'btn btn-danger']); ?>


                                    <?php echo Form::close(); ?>

                                    <a href="<?php echo e(route('episode.edit', $episode->id)); ?>" class="btn btn-warning">Sửa</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webphim_tutorial\resources\views/admincp/episode/index.blade.php ENDPATH**/ ?>