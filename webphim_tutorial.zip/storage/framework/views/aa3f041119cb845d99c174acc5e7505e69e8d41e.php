

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Quản lý link movie</div>

                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <li><?php echo e($error); ?></li>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(!isset($linkmovie)): ?>
                    <?php echo Form::open(['route' => 'linkmovie.store', 'method' => 'POST']); ?>

                    <?php else: ?>
                    <?php echo Form::open(['route' => ['linkmovie.update',$linkmovie->id],'method' => 'PUT']); ?>

                    <?php endif; ?>

                    <?php echo Form::open(['route' => 'linkmovie.store', 'method' => 'POST']); ?>

                    <div class="form-group">
                    <?php echo Form::label('title', 'Tên Link', []); ?>

                    <?php echo Form::text('title', isset($linkmovie) ? $linkmovie->title : '', ['class'=>'form-control','placeholder'=>'Nhập vào dữ liệu']); ?>

                    </div>


                    <div class="form-group">
                        <?php echo Form::label('description', 'Mô tả link', []); ?>

                        <?php echo Form::textarea('description', isset($linkmovie) ? $linkmovie->description : '', ['style'=>'resize:none','class'=>'form-control','placeholder'=>'Nhập vào dữ liệu','id'=>'title']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('active', 'Status', []); ?>

                        <?php echo Form::select('status', ['1'=>'Hiển thị','0'=>'Không'], isset($linkmovie) ? $linkmovie->status : '', ['class'=>'form-control']); ?>                    
                    </div>
                    <?php if(!isset($linkmovie)): ?>
                    <?php echo Form::submit('Thêm link', ['class'=>'btn btn-success']); ?>

                    <?php else: ?>
                    <?php echo Form::submit('Cập nhật link', ['class'=>'btn btn-success']); ?>

                     <?php endif; ?>
                    <?php echo Form::close(); ?>

                </div>
            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webphim_tutorial\resources\views/admincp/linkmovie/form.blade.php ENDPATH**/ ?>